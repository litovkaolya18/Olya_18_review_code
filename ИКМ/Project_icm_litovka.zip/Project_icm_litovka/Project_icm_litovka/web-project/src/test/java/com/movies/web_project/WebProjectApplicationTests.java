package com.movies.web_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
