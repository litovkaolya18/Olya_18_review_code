package com.movies.web_project.repository;

import com.movies.web_project.entity.Movie;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface MovieRepository extends JpaRepository<Movie, Long> {
    List<Movie> findByTitleContainingIgnoreCase(String title);
    List<Movie> findByReleaseYear(Integer releaseYear);
    List<Movie> findByDirectorId(Long directorId);
    List<Movie> findByGenreId(Long genreId);
}
