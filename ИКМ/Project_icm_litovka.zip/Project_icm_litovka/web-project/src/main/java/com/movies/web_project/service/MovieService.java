package com.movies.web_project.service;

import com.movies.web_project.entity.Movie;
import com.movies.web_project.entity.Director;
import com.movies.web_project.entity.Genre;
import com.movies.web_project.repository.MovieRepository;
import com.movies.web_project.repository.DirectorRepository;
import com.movies.web_project.repository.GenreRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class MovieService {
    private final MovieRepository movieRepository;
    private final DirectorRepository directorRepository;
    private final GenreRepository genreRepository;


    // === Movie CRUD ===
    public List<Movie> getAllMovies() {
        return movieRepository.findAll();
    }

    public Movie getMovieById(Long id) {
        return movieRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Фильм с ID " + id + " не найден"));
    }

    @Transactional
    public Movie saveMovie(Movie movie) {
        return movieRepository.save(movie);
    }

    @Transactional
    public void deleteMovie(Long id) {
        movieRepository.deleteById(id);
    }

    // Поиск
    public List<Movie> searchMovies(String title) {
        if (title != null && !title.trim().isEmpty()) {
            return movieRepository.findByTitleContainingIgnoreCase(title);
        }
        return getAllMovies();
    }

    // === Director CRUD ===
    public List<Director> getAllDirectors() {
        return directorRepository.findAll();
    }

    public Director getDirectorById(Long id) {
        return directorRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Режиссёр с ID " + id + " не найден"));
    }

    @Transactional
    public Director saveDirector(Director director) {
        return directorRepository.save(director);
    }

    @Transactional
    public void deleteDirector(Long id) {
        directorRepository.deleteById(id);
    }

    // === Genre CRUD ===
    public List<Genre> getAllGenres() {
        return genreRepository.findAll();
    }

    public Genre getGenreById(Long id) {
        return genreRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Жанр с ID " + id + " не найден"));
    }

    @Transactional
    public Genre saveGenre(Genre genre) {
        return genreRepository.save(genre);
    }

    @Transactional
    public void deleteGenre(Long id) {
        genreRepository.deleteById(id);
    }

    // Получить фильмы по режиссёру
    public List<Movie> getMoviesByDirector(Long directorId) {
        return movieRepository.findByDirectorId(directorId);
    }

    // Получить фильмы по жанру
    public List<Movie> getMoviesByGenre(Long genreId) {
        return movieRepository.findByGenreId(genreId);
    }
}
