package com.movies.web_project.controller;

import com.movies.web_project.entity.Movie;
import com.movies.web_project.entity.Director;
import com.movies.web_project.entity.Genre;
import com.movies.web_project.service.MovieService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Controller
@RequestMapping("/templates/directors/movies")
@RequiredArgsConstructor
public class MovieController {
    private final MovieService movieService;


    // Главная страница - список фильмов
    @GetMapping
    public String listMovies(
            @RequestParam(required = false) String search,
            Model model) {

        List<Movie> movies = movieService.searchMovies(search);
        model.addAttribute("templates/directors/movies", movies);
        model.addAttribute("search", search);
        return "templates/directors/movies/list";
    }

    // Форма добавления фильма
    @GetMapping("/new")
    public String showCreateForm(Model model) {
        Movie movie = new Movie();
        List<Director> directors = movieService.getAllDirectors();
        List<Genre> genres = movieService.getAllGenres();

        model.addAttribute("movie", movie);
        model.addAttribute("templates/directors", directors);
        model.addAttribute("templates/directors/genres", genres);
        model.addAttribute("isEdit", false);
        return "templates/directors/movies/form";
    }

    // Сохранение фильма
    @PostMapping("/save")
    public String saveMovie(@ModelAttribute Movie movie) {
        movieService.saveMovie(movie);
        return "redirect:/movies";
    }

    // Форма редактирования фильма
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        Movie movie = movieService.getMovieById(id);
        List<Director> directors = movieService.getAllDirectors();
        List<Genre> genres = movieService.getAllGenres();

        model.addAttribute("movie", movie);
        model.addAttribute("templates/directors", directors);
        model.addAttribute("templates/directors/genres", genres);
        model.addAttribute("isEdit", true);
        return "templates/directors/movies/form";
    }

    // Удаление фильма
    @GetMapping("/delete/{id}")
    public String deleteMovie(@PathVariable Long id) {
        movieService.deleteMovie(id);
        return "redirect:/movies";
    }

    // Просмотр деталей фильма
    @GetMapping("/view/{id}")
    public String viewMovie(@PathVariable Long id, Model model) {
        Movie movie = movieService.getMovieById(id);
        model.addAttribute("movie", movie);
        return "templates/directors/movies/view";
    }

    // === Director endpoints ===
    @GetMapping("/templates/directors")
    public String listDirectors(Model model) {
        List<Director> directors = movieService.getAllDirectors();
        model.addAttribute("templates/directors", directors);
        return "templates/directors/list";
    }

    @GetMapping("/templates/directors/new")
    public String showDirectorForm(Model model) {
        model.addAttribute("director", new Director());
        return "templates/directors/form";
    }

    @PostMapping("/templates/directors/save")
    public String saveDirector(@ModelAttribute Director director) {
        movieService.saveDirector(director);
        return "redirect:/movies/directors";
    }

    @GetMapping("/templates/directors/delete/{id}")
    public String deleteDirector(@PathVariable Long id) {
        movieService.deleteDirector(id);
        return "redirect:/movies/directors";
    }

    // === Genre endpoints ===
    @GetMapping("/templates/directors/genres")
    public String listGenres(Model model) {
        List<Genre> genres = movieService.getAllGenres();
        model.addAttribute("templates/directors/genres", genres);
        return "templates/directors/genres/list";
    }

    @GetMapping("/templates/directors/genres/new")
    public String showGenreForm(Model model) {
        model.addAttribute("genre", new Genre());
        return "templates/directors/genres/form";
    }

    @PostMapping("/templates/directors/genres/save")
    public String saveGenre(@ModelAttribute Genre genre) {
        movieService.saveGenre(genre);
        return "redirect:/movies/genres";
    }

    @GetMapping("/templates/directors/genres/delete/{id}")
    public String deleteGenre(@PathVariable Long id) {
        movieService.deleteGenre(id);
        return "redirect:/movies/genres";
    }
}
